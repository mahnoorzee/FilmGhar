import './allFilms.css';
import React, { Component, useState } from 'react';
import {Card, Row, Col, Button} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import movieData from './dummy.json';



// fetch('dummy.json')
// .then(response => response.json())
//         .then(data => {
//             console.log(data);
//             // name.innerHTML = data['name'];
//             // height.innerHTML = data['height'];
//             // skincolor.innerHTML = data['skin_color'];
//         })


  


function allFilms() {
    return (
        <div>
        <h1>Welcome to View All Films</h1>
        {movieData.map((m, index)=> {
            return <div>
            
            <div className="grid">
            <div className="container-fluid">
            <Row>
            <Col>
            
            <Card style={{ width: '18rem' }} className="box">
                    <Card.Img variant="top" src="holder.js/100px180" />
                    <Card.Body>
                        <Card.Title>{m.title}</Card.Title>
                        <Card.Text>{m.year}</Card.Text>
                        <Button variant="primary">Go somewhere</Button>
                    </Card.Body>
            </Card>
            
            </Col>
            </Row>
            </div>
            </div>
            </div>
        })}
    </div>
        )
    }

export default allFilms;