import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import filmlogo from './FilmGhar2-01.png';
import {Redirect, Router, useHistory, Link} from 'react-router-dom';
import {browserHistory} from 'react-router';
import './Navbar.css';

function Navbar() {

  const history = useHistory();

  const signUp = () => {
    history.push('#');
    console.log("HEYY");
    //<Redirect  to="#" />
 }

  return (
    <div className="NAVBAR">
      <nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <Link class="navbar-brand" to="#">
      <img src={filmlogo} width={70} height= {25}/>
    </Link>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      
   
   
      
      <div className="ml-auto tabs ">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item1">
          <Link class="nav-link active " aria-current="page" to='/allfilms'>View All Films</Link>
        </li>
        <li class="nav-item2">
          <button type="button" class="btn btn-outline-primary BTN" onClick={signUp}> Sign Up
         
          {/* <Link class="text" to="https://www.facebook.com/">SignUp</Link> */}
          </button>
          {/* <Link class="nav-link active" to="#">Profile</Link> */}
        </li>
      </ul>
      </div>
    </div>
  </div>
</nav>
    </div>
  )
}

  export default Navbar;
