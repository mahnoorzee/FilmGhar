import './App.css';
import React, { Component } from 'react';
import {Carousel, Button, Card, CardColumns, Row, Col, Container} from 'react-bootstrap';
import {Redirect, Switch, Route, Router} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './Components/Navbar';
import allFilms from './Components/allFilms';

// import cardCarousel from './Components/cardCarousel';
import img1 from './img1.jpg';
import img2 from './img2.jpg';
import img3 from './img3.jpg';

// import Carousel from './Components/Carousel';
{/* <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
  integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l"
  crossorigin="anonymous"
/> */}


// fetch("https://swapi.dev/api/people/"+randomNum)
//             .then(response => response.json())
//             .then(data => {
//                 console.log(data);
//                 text = data;
//                 console.log(text);
//                 // name.innerHTML = data['name'];
//                 // height.innerHTML = data['height'];
//                 // skincolor.innerHTML = data['skin_color'];
//             })


// class Items extends React.Component {

//   constructor(props) {
//     super(props)

//     this.state={
//       clicks: 0,
//       totalRemaining: 10
//     }
//   }

//   clickMeFunction() {
//     this.setState({
//       clicks: this.state.clicks + 1,
//       totalRemaining: this.state.totalRemaining - 1
//       // console.log("I CLICKED AT:", text)
//     })
//   }

//   render() {
//     return (
//       <div>
//       <h1 onClick={() => this.clickMeFunction()}>Hellloo from {this.props.name}</h1>
//       <span>{this.state.clicks} is the number of remaining {this.state.totalRemaining} click/s</span>
//       </div>
//       // <button onClick={() => this.clickMeFunction()}>Click Me</button>

//       //<button onClick={activateLasers}>Activate Lasers</button>;
//     )
//   }
// }
// class FilmLoopComp extends React.Component {
//   render() {
//     return (
//       <li>
//          <a href={this.props.link}>{this.props.link}</a>
//       </li>
//     )}
// }
// class StarWars extends React.Component {
//   constructor(){
//     super()
//     this.state = {
//       showcontent: false,
//       name: null,
//       height: null,
//       homeworld: null, 
//       films: [],
//     }
//   }
//   newChar() {
//     const randomNum = Math.floor(Math.random()*82)
//     console.log("New Character generated")
//     fetch("https://swapi.dev/api/people/"+randomNum)
//       .then(response => response.json())
//       .then(data => {
//         this.setState ({
//           showcontent: true,
//           name: data.name,
//           height: data.height,
//           homeworld: data.homeworld,
//           films: data.films,
    
//         })
//       })
    
//   }

//   render() {
//     const movies = this.state.films.map((url,i) => {
//       return <FilmLoopComp counter={i} link={url}/>
//       // return <li><a href={url}>{url}</a></li>
//     })


//     return (
//       // <div>
//       // {
//       //   <div>
//       //   this.state.showcontent &&
//       //     <div>
//       //       <h1> {this.state.name}</h1>
//       //       <p>{this.state.height}</p>
//       //       <p><a href = {this.state.homeworld}> HomeWorld </a></p>
//       //       <ul>{movies}</ul>
//       //     </div>
//           // <div>
       
     
 
      
      
//       // <button type="button" className="btn" onClick={() => this.newChar()}>Randomize</button>
//       // </div>
//     )
  
  
//   }
// }


function MyApp() {
  return (
    <div>
      <Navbar/>

      <Switch>
      <Route path="/" exact>
      <div className="container h-75 w-75">
      <Carousel >
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={img1}
      alt="First slide"
    />
    <Carousel.Caption className="text-md-left" >
    <h3>Second slide label</h3>
      <h6>Genre</h6>
      <p>Description</p>
      <button type="button" class="btn btn-outline-primary BTN2 lab">Watch Trailer</button>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={img2}
      alt="Second slide"
    />

    <Carousel.Caption className="text-md-left">
      <h3>Second slide label</h3>
      <h6>Genre</h6>
      <p>Description</p>
      <button type="button" class="btn btn-outline-primary BTN2 lab">Watch Trailer</button>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={img3}
      alt="Third slide"
    />

    <Carousel.Caption className="text-md-left">
    <h3>Second slide label</h3>
      <h6>Genre</h6>
      <p>Description</p>
      <button type="button" class="btn btn-outline-primary BTN2 lab" onClick={event =>  window.location.href='https://www.google.com/webhp?hl=en&sa=X&ved=0ahUKEwjh8sbVjcHvAhXSfMAKHcmpBHAQPAgI'}>Watch Trailer</button>
    </Carousel.Caption>
  </Carousel.Item>
</Carousel>
</div>

{/* <Row className="text-center">
  <Col md={2}>
    <Card style={{ width: '13rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
  </Col>  

  <Col md={2}>
    <Card style={{ width: '13rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
  </Col>  

  <Col md={2}>
    <Card style={{ width: '13rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
  </Col>  

  <Col md={2}>
    <Card style={{ width: '13rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
  </Col>  

  <Col md={2}>
    <Card style={{ width: '13rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
  </Col>  
</Row> */}
<div class="container-75 px-5 py-5">
<div class="row align-items-center">
                <div class="col-lg-2 col-md-12">
                <div class="card w-100">
                    <img
                    src="https://mdbootstrap.com/img/new/standard/nature/184.jpg"
                    class="card-img-top"
                    alt="..."
                    />
                    <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    
                    <a href="#!" class="btn btn-primary">Button</a>
                    </div>
                </div>
                </div>

                <div class="col-lg-2 col-md-12">
                <div class="card ">
                    <img
                    src="https://mdbootstrap.com/img/new/standard/nature/184.jpg"
                    class="card-img-top"
                    alt="..."
                    />
                    <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    
                    <a href="#!" class="btn btn-primary">Button</a>
                    </div>
                </div>
                </div>
                <div class="col-lg-2 col-md-12">
                <div class="card ">
                    <img
                    src="https://mdbootstrap.com/img/new/standard/nature/184.jpg"
                    class="card-img-top"
                    alt="..."
                    />
                    <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    
                    <a href="#!" class="btn btn-primary">Button</a>
                    </div>
                </div>
                </div>

                <div class="col-lg-2 col-md-12">
                <div class="card ">
                    <img
                    src="https://mdbootstrap.com/img/new/standard/nature/184.jpg"
                    class="card-img-top"
                    alt="..."
                    />
                    <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    
                    <a href="#!" class="btn btn-primary">Button</a>
                    </div>
                </div>
                </div>

                <div class="col-lg-2 d-none d-lg-block">
                <div class="card " >
                    <img
                    src="https://mdbootstrap.com/img/new/standard/nature/185.jpg"
                    class="card-img-top"
                    alt="..."
                    />
                    <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    
                    <a href="#!" class="btn btn-primary">Button</a>
                    </div>
                </div>
                </div>

                </div>

</div>   
</Route>
</Switch>  
  {/* <div class="container-25 overflow-hidden max-auto">
  <div class="">
    <div class="row gx-0">
        <div class="col-3 py-5 px-lg-5">
    <Card style={{ width: '12rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
    </div>
    <div class="col-3 py-5 px-lg-5">
    <Card style={{ width: '12rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
    </div>
    <div class="col-3 py-5 px-lg-5">
    <Card style={{ width: '12rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
    </div>
    <div class="col-3 py-5 px-lg-5">
    <Card style={{ width: '12rem' }}>
      <Card.Img variant="top" src="holder.js/100px180" />
      <Card.Body>
        <Card.Title>Card Title</Card.Title>
        <Card.Text>
          Some quick example text to build on the card title and make up the bulk of
          the card's content.
        </Card.Text>
        <Button variant="primary">Go somewhere</Button>
      </Card.Body>
    </Card>
    </div>
  </div>
  </div>

  </div> */}
      <Switch>
        <Route path="/allfilms" component={allFilms}>
        </Route>
      </Switch>
    </div>

  );
}

export default MyApp;


